-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 14-02-2018 a las 08:48:41
-- Versión del servidor: 10.1.30-MariaDB
-- Versión de PHP: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `productos`
--
CREATE DATABASE IF NOT EXISTS `productos` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `productos`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `iluminacion`
--

DROP TABLE IF EXISTS `iluminacion`;
CREATE TABLE `iluminacion` (
  `Id` int(11) NOT NULL,
  `Descripcion` varchar(50) DEFAULT NULL,
  `tipo` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `iluminacion`
--

INSERT INTO `iluminacion` (`Id`, `Descripcion`, `tipo`) VALUES
(0, '', ''),
(1, 'Twist 575 16ch', 'Robotica'),
(2, 'clypacky1000', 'Robotica'),
(3, 'mac300', 'Robotica'),
(4, 'mac quantum wash', 'Robotica'),
(5, 'IMG 200 scanner', 'Robotica'),
(6, 'rush mh5 75w', 'Robotica'),
(7, 'PAR65', 'FOCO'),
(8, 'PAR64', 'FOCO'),
(9, 'PURELITE RGBW PAR64', 'FOCO'),
(10, 'EUROLITE FOG 3000', 'MaqHumo'),
(11, 'IMG cambiaCOlor', 'Foco'),
(12, 'IMG', 'Robotica'),
(13, 'ClyPacky2000', 'Robotica'),
(25, 'cabeza movil scann 250w', 'Robotica'),
(55, 'sdfasdf', ''),
(100, 'value-2', 'value-3'),
(1025, 'ClyPacky 5000Lm', 'Robotica'),
(1111, 'Idoia', 'Maradiaga'),
(2525, 'Idoia', 'Maradiaga');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sonido`
--

DROP TABLE IF EXISTS `sonido`;
CREATE TABLE `sonido` (
  `Id` int(11) NOT NULL,
  `Descripcion` varchar(50) DEFAULT NULL,
  `tipo` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `sonido`
--

INSERT INTO `sonido` (`Id`, `Descripcion`, `tipo`) VALUES
(0, 'Doe', 'beringher'),
(1, 'asd1000W', 'AutoAmplif'),
(2, 'JBL Serie 500', 'AutoAmplif'),
(3, 'AVL250', 'AutoAmplif'),
(4, 'Allen & Heat', 'MesaSonido'),
(5, 'Yamaha 560', 'ConEtapa'),
(6, 'bombox100', 'MesaSonido'),
(7, 'Beringher', 'Autoamplif'),
(20, 'Beringher', 'Autoamplif'),
(22, 'fffff', 'fffff');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `iluminacion`
--
ALTER TABLE `iluminacion`
  ADD PRIMARY KEY (`Id`);

--
-- Indices de la tabla `sonido`
--
ALTER TABLE `sonido`
  ADD PRIMARY KEY (`Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
